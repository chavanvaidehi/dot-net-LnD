﻿namespace FirstMVCProject.Models
{
    public class Student
    {
        public string Name { get; set; }
        public int Marks { get; set; }

        public string GetResult()
        {
            return Marks >= 40 ? "Pass" : "Fail";
        }
    }
}
