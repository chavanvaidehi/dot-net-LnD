﻿using FirstMVCProject.Models;
using Microsoft.AspNetCore.Mvc;

namespace FirstMVCProject.Controllers
{
    public class StudentController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();  // shows form
        }

        [HttpPost]
        public IActionResult Result(Student student)
        {
            return View(student);  // shows result
        }
    }
}
