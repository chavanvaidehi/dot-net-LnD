using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FirstMVCProject.Views.Student
{
    public class ResultModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
