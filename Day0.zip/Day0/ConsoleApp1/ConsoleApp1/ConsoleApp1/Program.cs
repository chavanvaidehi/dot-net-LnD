﻿using System;


namespace ConsoleApp1
{


    internal class Program
    {
        static void Main(string[] args) {
            Student student = new Student();

            Console.Write("enter the student name:");
            student.Name = Console.ReadLine();
            Console.Write("enter the student nmarks:");
            student.Marks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nstudent Details");

            student.ShowDetails();
            student.CheckResult();

            Console.ReadLine();



        }

    }
}
