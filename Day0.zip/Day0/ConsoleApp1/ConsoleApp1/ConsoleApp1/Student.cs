﻿using System;

namespace ConsoleApp1
{
    public class Student
    {
        public string Name { get; set; } = string.Empty;
        public int Marks { get; set; }
        


        public void ShowDetails() {
            Console.WriteLine($"Name:{Name}");
            Console.WriteLine($"Marks:{Marks}");

        }
        public void CheckResult() {
            if (Marks > 40) Console.WriteLine("Result: pass");
            else
                Console.WriteLine("Result: Fail");
        }
    }
}
